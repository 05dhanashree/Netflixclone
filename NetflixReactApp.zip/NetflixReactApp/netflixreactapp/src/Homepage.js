import React from "react";
import { useNavigate } from "react-router-dom";

function Homepage  ()  {

    const navigate = useNavigate();
  return (
    <>
    
    <main className="container-fluid image">
        <section className="row py-lg-3 py-2">
            <header className="col-12 col-lg-11 m-auto text-white d-flex justify-content-between">
                <img src="./images/logo.jpg" className="logo"/>
                <div>
                    <select name="language" id="language">
                        <option value="English">English</option>
                        <option value="Hindi">हिंदी</option>
                    </select>
                    <div className="btn btn-outline-dark bg-danger text-white">Sign In</div>
                </div>
            </header>
        </section> 


        <section className="row mt-4">
            <section className="col-12 col-lg-6 m-auto text-white d-flex flex-wrap justify-content-center">
                <p className="brandcafe  mb-0 fw-bold text-center">Unlimited movies,TV shows and more.</p>   
                <p className="mb-0 text-center fs-4 ">Watch anywhere.Cancel anytime.</p> 
                <p className="mb-0 text-center fs-4">Ready to watch?Enter your email to create or restart your membership.</p> 
                
                                 
            </section>
        </section>            
                    
                
                <section>                    

                <form className="emailsignup">
                    <input type="email" placeholder="Email address" required/>
                    <div className="btn btn-outline-dark bg-danger text-white style2 emailsignup">
                     <button onClick={() => navigate("/Search")}>Get Started</button>
                    </div>
                </form>                        
                                 
        </section>
    </main> 
    

    </>
  )
}

export default Homepage;
