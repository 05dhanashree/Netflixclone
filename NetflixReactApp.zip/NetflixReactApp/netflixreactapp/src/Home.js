
import Homepage from "./Homepage";




const Home = () => {
  
  return (
    <>
    <Homepage />   
    
    </>
  )
 
}

export default Home;
