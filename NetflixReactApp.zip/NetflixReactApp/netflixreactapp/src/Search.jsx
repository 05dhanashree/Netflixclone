import React from "react";
import { useGlobalContext } from "./context";
import Movies from "./Movies";

const Search = () => {
  const { query, setQuery, isError} = useGlobalContext();
  return <>
    <main class="container-fluid image">
            <section className="row py-lg-3 py-2">
                <header className="col-12 col-lg-11 m-auto text-white d-flex flex-wrap gap-4 justify-content-between">
                    <img src="images/logo.jpg" class="logo"/>
                    <div className=" d-flex flex-wrap gap-4 m-auto">
                    <p className="mb-0 text-white fs-4">Home</p>
                    <p className="mb-0 text-white fs-4">TV Shows</p>
                    <p className="mb-0 text-white fs-4">Movies</p>
                    <p className="mb-0 text-white fs-4">New & Popular</p>
                    <p className="mb-0 text-white fs-4">My List</p> 
                    </div>
                                                    
                    
                </header>
            </section>     

</main>      
    

  <section className="search-section">
    <h2 className="text-white">Search your favourite movie</h2>
    <form action="#" onSubmit={(e) => e.preventDefault()}>
      <div>
        <input 
        type="text"
        placeholder="search here"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        />
      </div>
    </form>
    <div className="card-error">
      <p>{isError.show && isError.msg}</p>
    </div>
  </section>

  <Movies />
  
  </>  
}

export default Search;
